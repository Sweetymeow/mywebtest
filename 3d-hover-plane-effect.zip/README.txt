A Pen created at CodePen.io. You can find this one at http://codepen.io/ariona/pen/JopOOr.

 Simple 3D plane hover effect using CSS3 transform