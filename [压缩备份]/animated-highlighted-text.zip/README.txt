A Pen created at CodePen.io. You can find this one at http://codepen.io/ariona/pen/LEEadb.

 This pen was inspired by webdesignerdepot's new design, the title on each article will be highlighted when user hovered it.

The idea is simple, it make used of linear gradient and transition.

1. We set the title to be inline element (This will break every background when the title breaked into lines)
2. Apply linear-gradient background, with half transparent-color, and highlighted color on the other half. then make it 200% size.
3. Change the background-position-x to -100%, it will push the highligted color 100% to the right.
4. Apply transition property to get the nice sliding effect.
