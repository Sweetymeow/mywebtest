A Pen created at CodePen.io. You can find this one at http://codepen.io/JacobStone420/pen/GfLEn.

 Implementation of Alessio Atzeni's CSS3 effects using masks and hover effects. 